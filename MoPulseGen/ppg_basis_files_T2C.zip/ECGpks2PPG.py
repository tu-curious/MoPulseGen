# -*- coding: utf-8 -*-
"""
Created on Sun Aug 18 13:10:07 2019

@author: agarwal.270a
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import glob
import pickle
import scipy.signal as sig
from scipy import io

def filtr(X0,Fs=25,filt=True):
    nyq=Fs/2
    X1 = sig.detrend(X0,type='constant',axis=0); # Subtract mean
    if filt:
        # filter design used from Ju's code with slight changes for python syntax
        b = sig.firls(219,np.array([0,0.3,0.5,4.5,5,nyq]),np.array([0,0,1,1,0,0]),np.array([10,1,1]),nyq=nyq);
        X=np.zeros(X1.shape)
        for i in range(X1.shape[1]):
            #X[:,i] = sig.convolve(X1[:,i],b,mode='same'); # filtering using convolution, mode='same' returns the 'centered signal without any delay
            X[:,i] = sig.filtfilt(b,[1],X1[:,i])

    else:
        X=X1
    #X=sig.detrend(X,type='constant',axis=0); # subtracted mean again to center around x=0 just in case things changed during filtering
    return X

def remove_outliers(A):
    '''
    A: a matrix made of row vectors
    naively remove outlier vectors by remove top 5 percentile in magnitude
    '''
    mags=np.linalg.norm(A,axis=1)
    thres=np.nanpercentile(mags,95)
    idx=np.sort(np.arange(len(A))[mags<thres])
    return A[idx]

def pca(X):
  # Data matrix X, assumes 0-centered
  n, m = X.shape
  avg=X.mean(axis=0)
  X=X-avg
  assert np.allclose(X.mean(axis=0), np.zeros(m))
  # Compute covariance matrix
  C = np.matmul(X.T, X) / (n-1)
  #np.allclose(C, C.T, rtol=1e-5, atol=1e-8)
  #print(np.array_equal(C, C.T))

  # Eigen decomposition
  eigen_vals, eigen_vecs = np.linalg.eigh(C)
  sort_idx=np.argsort(-eigen_vals) #-ve to sort in descending order
  eigen_vals, eigen_vecs=eigen_vals[sort_idx], eigen_vecs[:,sort_idx]
  return eigen_vals,eigen_vecs,avg

w_l=5;w_pk=25;w_r=w_pk-w_l-1

def get_ppg_winds(r_pk_locs,y,make_plots=False):
    '''
    find and store peaks from filtered signal
    r_pk_locs: R-peak locations
    y:clean_ppg
    
    Should I take pk shapes looking from ECG perspective or correct for PTT?
    Right now I take from ECG persepective so that after PCA, the components
    will have implicit PTT.
    '''

    # Use when correcting for PTT
# =============================================================================
#     r_pk_win=7
#     #remove terminal pk_locs
#     r_pk_locs=r_pk_locs[(r_pk_locs>=r_pk_win) & (r_pk_locs<(len(y)-r_pk_win))]
#     y_pk_shapes=np.array([y[i-r_pk_win:i+r_pk_win] for i in r_pk_locs])
#     pk_locs=r_pk_locs+(np.argmax(y_pk_shapes,axis=1)-r_pk_win)
# =============================================================================
    #Use otherwise
    pk_locs=r_pk_locs*1

    #counts_1 = 1;counts_2 = 1;counts_3 = 1;
    global w_l,w_r
    
    #remove terminal pk_locs
    pk_locs=pk_locs[(pk_locs>=w_l) & (pk_locs<(len(y)-w_r))]
    
    # add peaks
    #windowsPPG1 = []
    #for i in range(len(pk_locs)):
    windowsPPG1=[y[pk_locs[i]-w_l:pk_locs[i]+w_r+1] \
                 for i in range(len(pk_locs))]
    windowsPPG1=np.array(windowsPPG1)

    if make_plots:
        plt.close('all');j=0
        while j<len(windowsPPG1)/20:
            plt.figure();k=1
            while ((k<=8) and (j+k)<len(windowsPPG1)):
                plt.subplot(4,2,k)
                cntr=j+k;
                plt.plot(windowsPPG1[cntr],'r')
                plt.grid(True)
                plt.title('Peak '.format(cntr))
                k=k+1;
            j=j+8;
    
    return windowsPPG1

def get_ppg_basis(list_arr_pks,list_clean_ppg,path,save_flag=True,\
                  make_plots=True):
    list_r_pk_locs=[np.arange(len(arr_pks))[arr_pks.astype(bool)] for arr_pks in\
               list_arr_pks]
    list_r_pk_locs_dsampled=[np.floor(r_pk_locs/4).astype(int) for r_pk_locs \
                             in list_r_pk_locs] #get nearest dsampled idx
    list_wins_clean_ppg=[get_ppg_winds(r_pk_locs,y) for r_pk_locs,y in \
                   zip(list_r_pk_locs_dsampled,list_clean_ppg)]
    wins_clean_ppg=np.concatenate(list_wins_clean_ppg, axis=0)
    mat1=remove_outliers(wins_clean_ppg)
    #find eig values and observe
    eigen_vals1,eigen_vecs1,avg1=pca(mat1) 
    
    if make_plots:
        plt.figure();plt.subplot(121);plt.plot(eigen_vals1)
        plt.subplot(122);plt.plot(avg1)
        j=0
        while j<15:
            plt.figure();k=1
            while ((k<=8) and (j+k)<len(eigen_vals1)):
                plt.subplot(4,2,k)
                cntr=j+k;
                plt.plot(eigen_vecs1[:,cntr],'r')
                plt.grid(True)
                plt.title('eig_peak '.format(cntr))
                k=k+1;
            j=j+8;
            
    #Decide on k and store basis
    basis_dict={'eig_val':eigen_vals1,'eig_vec':eigen_vecs1,'mean':avg1}
    if save_flag:
        #pickle.dump(basis_dict, open(path+"green_ppg_basis.dat", "wb"))  # save it into a file named save.p
        io.savemat(path+"green_ppg_basis.mat",mdict=basis_dict)
    return basis_dict
    #k=10
    #mdict[p_id+'_{}'.format(led_id[j])]['peaks']={'peak_mat':mat1,\
    #'eig_vec':eigen_vecs1[:,:k],'mean':avg1,'eig_val':eigen_vals1[:k]}


def gen_ppg_from_ECG(arr_pks,basis_dict):
    '''

    '''
    k=10
    global w_l,w_r
    r_pk_locs=np.arange(len(arr_pks))[arr_pks.astype(bool)]
    r_pk_locs=np.floor(r_pk_locs/4).astype(int) #get nearest dsampled idx
    #remove terminal pk_locs
    r_pk_locs=r_pk_locs[(r_pk_locs>=w_l) & (r_pk_locs<=(int(len(arr_pks)/4)-w_r-1))]
    
    n_peaks=int(len(arr_pks)/(4*5))
    #sample bunch of peaks using PCA components
    eig_vec=basis_dict['eig_vec'];eig_val=basis_dict['eig_val'].reshape((-1,1))
    avg=basis_dict['mean'].reshape((-1,1))
    eig_vec=eig_vec[:,:k];eig_val=eig_val[:k]
    l_peaks,n_coeff=eig_vec.shape
    weights=np.random.random_sample((n_coeff,n_peaks))*(eig_val**0.5)
    rand_pks=np.matmul(eig_vec,weights)+avg #form peaks
    #rand_pks=rand_pks[int(l_peaks/2)-w_l:int(l_peaks/2)+w_r+1,:] #keep desired width
# =============================================================================
#     
#     j=0
#     while j<len(rand_pks.T)/200:
#         plt.figure();k=1
#         while ((k<=8) and (j+k)<len(rand_pks.T)):
#             plt.subplot(4,2,k)
#             cntr=j+k;
#             plt.plot(rand_pks[:,cntr],'r')
#             plt.grid(True)
#             plt.title('Formed Peak '.format(cntr))
#             k=k+1;
#         j=j+8;
# =============================================================================
        
    arr_ppg=np.zeros(int(len(arr_pks)/4))
    #arr_pk=np.zeros(len(HR_curve1))
    #TODO: bunch of changes here
    #gauss=norm(loc = 0., scale = 1.5).pdf(np.arange(-3,3+1))
    #PTT=np.random.randint(4,8) #sample a PTT value
    #plt.figure();plt.plot(gauss)
    #print(np.max(r_pk_locs),len(arr_ppg))
    for i in range(len(r_pk_locs)):
        arr_ppg[r_pk_locs[i]-w_l:r_pk_locs[i]+w_r+1]+=rand_pks[:,i]
    arr_ppg_filt=filtr(arr_ppg.reshape(-1,1))
    #plt.figure();plt.plot(arr_ppg);plt.plot(arr_ppg_filt,'g--')
    #plt.plot(r_pk_locs,arr_ppg[r_pk_locs],'r+')
    return arr_ppg_filt.reshape(-1),r_pk_locs

def get_clean_ppg_and_ecg(files):
    '''
    
    '''
    Fs=25
    list_clean_ppg=[];list_arr_pks=[]
    #clean_idx=[(2*Fs,14*Fs),(122*Fs,134*Fs),((242*Fs,254*Fs))]
    for i in range(len(files)):
        #print(files[i],files[i] in val_names)
        #i=0;
        df=pd.read_csv(files[i],header=None)
        arr=df.values
# =============================================================================
#         if 'L' in files[i]: #left hand was moving
#             list_clean_ppg+=[arr[(k+2)*Fs:(k+14)*Fs,9+18] for k in \
#                             2*60*np.arange(int(len(arr)/(2*60*Fs)))]
#             list_arr_pks+=[arr[(k+2)*Fs:(k+14)*Fs,41:45].reshape(-1) for k in \
#                             2*60*np.arange(int(len(arr)/(2*60*Fs)))]
#             list_clean_ppg+=[arr[:,18+18]]
#             list_arr_pks+=[arr[:,41:45].reshape(-1)]
#         elif 'R' in files[i]: #right hand was moving
#             list_clean_ppg+=[arr[(k+2)*Fs:(k+14)*Fs,18+18] for k in \
#                             2*60*np.arange(int(len(arr)/(2*60*Fs)))]
#             list_arr_pks+=[arr[(k+2)*Fs:(k+14)*Fs,41:45].reshape(-1) for k in \
#                             2*60*np.arange(int(len(arr)/(2*60*Fs)))]
#             list_clean_ppg+=[arr[:,9+18]]
#             list_arr_pks+=[arr[:,41:45].reshape(-1)]
# =============================================================================
        if 'clean' in files[i]:
            list_clean_ppg+=[arr[:,29],arr[:,30],arr[:,39],arr[:,40]]
            list_arr_pks+=4*[arr[:,45:49].reshape(-1)]
        #print(len(list_arr_pks))
# =============================================================================
#     j=0
#     list_r_pk_locs=[np.arange(len(arr_pks))[arr_pks.astype(bool)] for arr_pks in\
#                list_arr_pks]
#     list_r_pk_locs_dsampled=[np.floor(r_pk_locs/4).astype(int) for r_pk_locs \
#                              in list_r_pk_locs]
#     while j<2:
#         h=plt.figure();k=1
#         while ((k<=8) and (j+k)<len(list_arr_pks)):
#             plt.subplot(4,2,k)
#             cntr=j+k;
#             plt.plot(list_clean_ppg[cntr],'b')
#             plt.plot(list_r_pk_locs_dsampled[cntr],\
#                     (list_clean_ppg[cntr])[list_r_pk_locs_dsampled[cntr]],'r+')
#             plt.grid(True);plt.title('clean_ppg with R-peaks'.format(cntr))
#             k=k+1;
#         #time.sleep(2);
#         #plt.close(h);
#         j=j+8;
# =============================================================================
        
    return list_arr_pks,list_clean_ppg

def main():
    path_prefix='E:/Box Sync/' #'C:/Users/agarwal.270/Box/' #'E:/Box Sync/'
    path=path_prefix+'SU19/Research/PPG_ECG_Proj/Data_5_Aug/files/Wen_data_5aug\\'
    files=glob.glob(path+'*.csv')
    files=[fil for fil in files if 'WZ' in fil] #get wenxiao's data
    
    val_names=['2019080422_preproc_WZ_R.csv']
    test_names=['2019080423_preproc_WZ_L.csv']
    #separate val and test files
    files=[fil for fil in files if not((val_names[0] in fil) | \
                                       (test_names[0] in fil))]
    list_arr_pks,list_clean_ppg=get_clean_ppg_and_ecg(files)
    basis_dict=get_ppg_basis(list_arr_pks,list_clean_ppg)
    