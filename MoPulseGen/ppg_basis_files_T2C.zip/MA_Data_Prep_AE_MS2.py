import numpy as np
import glob
import pandas as pd
import matplotlib.pyplot as plt
from data.sim_for_model_4 import sinusoid
from scipy import signal as sig
from data.ECGpks2PPG import get_clean_ppg_and_ecg,get_ppg_basis,gen_ppg_from_ECG
from pathlib import Path
import pickle
from scipy import io

def form_data(X,Y,len_in,len_out,step):
    '''
    X:timeseries with inputs
    Y:timeseries with outputs
    '''
    in_size=len_in
    out_size=len_out
    step_size=step#np.max([out_size,4]) #change this as desired
    
    #clip timeseries to nearest multiple of step_size
    #lenth1=(((len(X)-in_size)//step_size)*step_size)+in_size
    lenth=len(X)
    #print(lenth1,lenth)
    X,Y=X.T,Y.T # Transpose to make it look like time-series
    X,Y=X.reshape(X.shape+(1,)),Y.reshape(Y.shape+(1,)) # add a dimension for concatenation
    
    #idx=np.arange(0,lenth-in_size,step_size)+in_size
    idx=step_size*np.arange(0,1+((lenth-in_size)//step_size))+in_size
    #print(idx[-1])
    #print(lenth,X.shape[1],len(idx),(X.shape[1]-in_size+1)//step_size)
    #print(X.shape,Y.shape,HR.shape)
    data_X=np.concatenate([X[:,i-in_size:i,:] for i in idx],axis=-1).T
    data_Y=np.concatenate([Y[i-out_size:i,:] for i in idx],axis=-1).T
    #kernel_size=100;stride=1
    #idxHR=np.arange(i-out_size+kernel_size,i,stride)
    return data_X,data_Y

def form_sin(data_Y_l,Fs=25):
    Fs=25
    temp_Y=np.fft.fft(data_Y_l,n=int(data_Y_l.shape[1]*2-1),axis=1)
    freq = np.fft.fftfreq(temp_Y.shape[1],d=1/Fs)
    temp_Y,freq=temp_Y[:,:int(len(freq)/2)+1],freq[:int(len(freq)/2)+1]
    
    sort_amps=np.sort(np.abs(temp_Y),axis=1)
    amp_Y=sort_amps[:,-1]
    amp_2Y=sort_amps[:,-2]
    amp_3Y=sort_amps[:,-3]
    amp_4Y=sort_amps[:,-4]
    
    sort_idx=np.argsort(np.abs(temp_Y),axis=1)
    freq_Y=freq[sort_idx[:,-1]]
    freq_2Y=freq[sort_idx[:,-2]]
    freq_3Y=freq[sort_idx[:,-3]]
    freq_4Y=freq[sort_idx[:,-4]]
    
    #plt.figure();plt.plot(freq_Y)
    t1=np.arange(data_Y_l.shape[1])/Fs
    
    #find sinusoids
    sin_Y=np.array([amp_Y[i]*sinusoid(t1,freq_Y[i]*2*np.pi,phi=0)[1] \
                    for i in range(len(freq_Y))])
    sin_2Y=np.array([amp_2Y[i]*sinusoid(t1,freq_2Y[i]*2*np.pi,phi=0)[1] \
                     for i in range(len(freq_2Y))])
    sin_3Y=np.array([amp_3Y[i]*sinusoid(t1,freq_3Y[i]*2*np.pi,phi=0)[1] \
                    for i in range(len(freq_3Y))])
    sin_4Y=np.array([amp_4Y[i]*sinusoid(t1,freq_4Y[i]*2*np.pi,phi=0)[1] \
                     for i in range(len(freq_4Y))])
    
    mix_sin_Y=sin_Y+sin_2Y+sin_3Y+sin_4Y
    #find phase diff
    shft = np.array([np.argmax(sig.correlate(mix_sin_Y[i], data_Y_l[i])) \
            - len(data_Y_l[i]) for i in range(len(freq_Y))])
    phi_t=shft/Fs
    mix_sin_Y=np.array([sinusoid(t1,freq_Y[i]*2*np.pi,\
                    phi=phi_t[i]*freq_Y[i]*2*np.pi)[1] \
                    for i in range(len(freq_Y))])
    plt.figure();plt.plot(mix_sin_Y[3]);plt.plot(data_Y_l[3])
    plt.legend(['ppg','sinusoid'])
    return mix_sin_Y

def data_prep(path,files,val_files=[],test_files=[],make_plots=False,\
              for_test=False,len_in=128,len_out=128,step=32):
    '''
    path: Absolute path to the folder having data
    files: filenames of all data files
    
    '''
    #path_prefix='E:/Box Sync/' #'C:/Users/agarwal.270/Box/' #'E:/Box Sync/'
    #path=path_prefix+'SU19/Research/PPG_ECG_Proj/Data_5_Aug/files/Wen_data_5aug\\'
    #files=glob.glob(path+'*.csv')
    #files=[fil for fil in files if 'WZ' in fil] #get wenxiao's data
    
    #files=[fil for fil in files if '052' not in fil] #remove dirty data
    # =============================================================================
#     val_names=[path+'2019070716_preproc_WZ_R_2.csv',\
#                path+'2019070816_preproc_WZ_L.csv',\
#                path+'2019070422_preproc_WZ_R_2.csv']
#     test1='2019070717_preproc_WZ_R'
#     test2='2019070817_preproc_WZ_L_0'
#     test_names=[test1,test2]
# =============================================================================
    #val_names=[path+'2019070521_preproc_WZ_L.csv',path+'2019070716_preproc_WZ_L.csv']
    #test_names=['2019070421_preproc_WZ_L.csv']
    
    #val_names=[path+'2019080422_preproc_WZ_R.csv']
    #test_names=['2019080423_preproc_WZ_L.csv']
    #separate test file
    if for_test:
        #files=[test_files[np.random.randint(len(test_files))]]
        files=[test_files[-1]]

        print('returning data of file '+files[0])
        #files=[fil for fil in files if test_file in fil]
    else:
        #files=[fil for fil in files if not((test1 in fil) | (test2 in fil))]
        s1=set(files);s2=set(test_files)
        files=list(s1.difference(s2))
        #files=[fil for fil in files if not(test_names[0] in fil)]
    
    # Get the basis vectors
    if Path(path+"green_ppg_basis.mat").is_file():
        basis_dict = io.loadmat(path+"green_ppg_basis.mat")#(open(path+"green_ppg_basis.mat", "rb"))
    else:
        #separate val and test files
        s3=set(files);s4=set(val_files)
        files_2=list(s3.difference(s4))
        #files_2=[fil for fil in files if not((val_names[0] in fil))]
        list_arr_pks,list_clean_ppg=get_clean_ppg_and_ecg(files_2)
        #print(len(files_2),len(list_arr_pks))
        basis_dict=get_ppg_basis(list_arr_pks,list_clean_ppg,path,save_flag=True)
        print('Saved the basis. Re-run to use it and find dataset.')
        return [[0]],[[0]],[[0]]
    
    input_list_l1=np.array([7,8,9,10])+20
    input_list_r1=np.array([7,8,9,10])+30
    #input_list_l1=np.array([1,2,3,7,9])+20
    #input_list_l2=np.array([1,2,3,8,10])+20
    #input_list_r1=np.array([1,2,3,7,9])+30
    #input_list_r2=np.array([1,2,3,8,10])+30
    
    #print(len(files),val_names)
    for i in range(len(files)):
        #print(files[i],files[i] in val_names)
        #i=0;
        df=pd.read_csv(files[i],header=None)
        arr=df.values
        #if 'L' in files[i]: #left hand was moving
        X_l1=arr[:,input_list_l1]
        #X_l2=arr[:,input_list_l2]
        Y_l,r_pk_locs=gen_ppg_from_ECG(arr[:,45:49].reshape(-1),basis_dict)
        X_r1=arr[:,input_list_r1]
        #X_r2=arr[:,input_list_r2]
        Y_r=1*Y_l
        #true_ppg=arr[:,18+18]
            
        if make_plots:
            plt.figure();plt.plot(Y_l,'g--')
            plt.plot(r_pk_locs,Y_l[r_pk_locs],'r+')
            plt.grid(True);plt.legend(['Synthetic PPG','R_peaks'])
            
        data_X_l1,data_Y_l1=form_data(X_l1,Y_l,len_in,len_out,step)
        #data_X_l2,data_Y_l2=form_data(X_l2,Y_l,len_in,len_out,step)
        data_X_r1,data_Y_r1=form_data(X_r1,Y_r,len_in,len_out,step)
        #data_X_r2,data_Y_r2=form_data(X_r2,Y_r,len_in,len_out,step)

        #TODO: replace clean_ppg with most likely and correlated sinusoid
        #data_Y_l=form_sin(data_Y_l)
        #data_Y_r=form_sin(data_Y_r)
        #data_Y_r=1*data_Y_l
        
        #test
        if for_test:
            return X_l1,data_X_l1,Y_l,X_r1,data_X_r1,Y_r
        
        #val
        if files[i] in val_files:
            if 'val_data_X' not in locals():
                val_data_X=np.concatenate([data_X_l1,\
                                           data_X_r1],axis=0)
                val_data_Y=np.concatenate([data_Y_l1,\
                                           data_Y_r1],axis=0)
            else:
                val_data_X=np.concatenate([val_data_X,data_X_l1,\
                                           data_X_r1],axis=0)
                val_data_Y=np.concatenate([val_data_Y,data_Y_l1,\
                                           data_Y_r1],axis=0)
        else:
            if 'train_data_X' not in locals():
                train_data_X=np.concatenate([data_X_l1,\
                                           data_X_r1],axis=0)
                train_data_Y=np.concatenate([data_Y_l1,\
                                           data_Y_r1],axis=0)
            else:
                train_data_X=np.concatenate([train_data_X,data_X_l1,\
                                           data_X_r1],axis=0)
                train_data_Y=np.concatenate([train_data_Y,data_Y_l1,\
                                           data_Y_r1],axis=0)
    
    
    #shuffle Training data
    #idx = np.random.permutation(len(dataset_Y))
    #dataset_X,dataset_Y=dataset_X[idx],dataset_Y[idx]
    
    #separate test into val and test
    #ratio=0.11 # 1-ratio->train, ratio->val
    #cut_idx=int(ratio*len(dataset_Y))#;cut_idx2=int(ratio2*len(data_Y))
    
    #val_data=(dataset_X[:cut_idx],dataset_Y[:cut_idx])
    #train_data=(dataset_X[cut_idx:],dataset_Y[cut_idx:])
    val_data=(val_data_X,val_data_Y)
    train_data=(train_data_X,train_data_Y)
    test_data = (np.copy(val_data[0]),np.copy(val_data[1]))
    
    
    return train_data,val_data,test_data